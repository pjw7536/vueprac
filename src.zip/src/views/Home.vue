<template>
  <div>
    <h1>Home Page</h1>
    <p>Welcome to the home page!</p>
  </div>
</template>

<script setup>
// 필요한 경우 스크립트 추가
</script>

<style scoped>
/* 스타일 추가 가능 */
</style> 